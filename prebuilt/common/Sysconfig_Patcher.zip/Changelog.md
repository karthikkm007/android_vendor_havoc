# 2017.12.3 (201712030)
- Better & wider compatibility -- from Magisk 12 all the way to 14.5, possibly previous and future versions too
- Patching optimizations
- Updated reference

# 2017.11.9 (201711090)
- General optimizations

# v2017.10.15 (201710150)
* Redesigned/enhanced patching & auto-re-patching mechanisms.
* New version code format YYYYMMDDD
-- Magisk Manager won't recognize this as an update.

# v2017.10.9 (201710900)
- Auto-re-patching optimizations

# v2017.9.24 (20179240)
- Fixed automatic re-patching after ROM/GApps updates.
- Template 1400
- Updated reference.

# V2017.9.5
- Minor cosmetic changes

# v2017.8.23
- Major optimizations
- Initial release

# v2017.8.21
- Initial version